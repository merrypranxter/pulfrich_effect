# Visual Targets: pulfrich_effect

> TODO: describe desired visual output, color palettes, and animation behavior.
