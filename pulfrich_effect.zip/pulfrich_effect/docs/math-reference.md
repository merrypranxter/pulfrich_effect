# Math Reference: pulfrich_effect

> TODO: add mathematical foundations, equations, and reference values.
