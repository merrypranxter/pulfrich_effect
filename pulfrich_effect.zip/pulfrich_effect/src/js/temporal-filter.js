// Exponential moving average per eye
