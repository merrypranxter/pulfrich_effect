// Pendulum, ball, and landscape motion
