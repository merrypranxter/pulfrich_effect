// Pulfrich effect renderer
