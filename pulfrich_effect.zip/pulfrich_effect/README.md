# pulfrich_effect

> one eye dark. one eye bright. time lag creates depth.

The Pulfrich effect rendered as a real-time shader system. One eye receives a temporally blurred/delayed frame while the other gets the current frame. When viewing a moving scene, the temporal lag creates a positional disparity between the eyes, producing a vivid depth illusion. Parameterize dark-eye lag, scene motion speed, and filter strength.

## Live Controls

| Key | Action |
|-----|--------|
| `Space` | Toggle Pulfrich filter on/off |
| `↑ / ↓` | Increase / decrease temporal lag |
| `← / →` | Decrease / increase scene motion speed |
| `D` | Toggle dark eye (left/right) |
| `S` | Show split-screen comparison |
| `P` | Pendulum scene (classic demo) |

## Named Regimes

- **Pendulum** — Classic swinging bob, apparent elliptical trajectory
- **Bouncing Ball** — Vertical motion, depth from bounce
- **Scrolling Landscape** — Horizontal motion, depth from speed
- **Particles** — Random motion, emergent depth field
- **Reverse Pulfrich** — Dark eye on the other side, depth sign flips
- **Extreme Lag** — 200 ms, exaggerated but unstable depth

## The Math

Temporal lag model:
- Dark eye: L_d(t) = α · L(t) + (1-α) · L_d(t-1)
- Where α = 1 / (1 + lag_factor)
- Bright eye: L_b(t) = L(t) (no lag)
- Disparity: Δx = v · τ
- Where v = scene velocity, τ = effective lag time

Depth from disparity:
- Standard stereopsis: z = baseline · f / Δx
- Pulfrich: baseline = eye separation, Δx from temporal lag
- Depth sign: depends on motion direction and dark eye side

## Acknowledgments

Carl Pulfrich (1922), *The Stereoscopic Phenomenon of the Pulfrich Effect*, modern VR applications by Andrew Woods.
